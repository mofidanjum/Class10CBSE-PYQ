# CBSE Class 10 MCQ Quiz

A practice app for CBSE Class 10 Physics, Chemistry, Biology and Maths.

- `web/` – the app itself (one HTML page + question files). This is the source of truth.
- `android/` – a tiny Android wrapper (a full-screen WebView) that bundles `web/` so the app works offline.
- `scripts/build_web.sh` – copies `web/` into the Android project.
- `.github/workflows/build-apk.yml` – on every push to `main`, GitHub builds a signed APK and attaches it to the **latest** release.

## Adding questions
Add objects to one of the question files in `web/`:
`{ id, s: "physics|chemistry|biology|maths", ch, src, q, o: [4 options], a: correctIndex, e: explanation, fixed? }`
Use a unique `id`. Set `fixed: true` when option order matters (Assertion–Reason, "I and III" style).

## Signing key
`android/keystore/` holds the key that signs every APK. Keep it: Android only installs an update
if it is signed with the same key. (The repo is private; the passwords are simple on purpose.)
