#!/usr/bin/env bash
# Copies the web app into the Android project as a complete, offline HTML page.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/android/app/src/main/assets/www"
mkdir -p "$OUT"
{
  echo '<!doctype html><html lang="en"><head><meta charset="utf-8">'
  echo '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">'
  echo '<style>[hidden]{display:none!important}html,body{margin:0}img{max-width:100%}</style>'
  echo '</head><body>'
  cat "$ROOT/web/index.html"
  echo '</body></html>'
} > "$OUT/index.html"
cp "$ROOT"/web/*.js "$OUT/"
echo "Web app copied to $OUT"
