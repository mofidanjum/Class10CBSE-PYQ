// Chapter order (as in the NCERT books) and a quick-revision cheat sheet for every chapter.
// Format: CHEATSHEETS[chapter] = [ [heading, [point, point, ...]], ... ]  (HTML allowed)
window.CHAPTERS = {
  physics: ["Light – Reflection and Refraction","The Human Eye and the Colourful World","Electricity","Magnetic Effects of Electric Current"],
  chemistry: ["Chemical Reactions and Equations","Acids, Bases and Salts","Metals and Non-metals","Carbon and its Compounds"],
  biology: ["Life Processes","Control and Coordination","How do Organisms Reproduce?","Heredity","Our Environment"],
  maths: ["Real Numbers","Polynomials","Pair of Linear Equations in Two Variables","Quadratic Equations","Arithmetic Progressions","Triangles",
    "Coordinate Geometry","Introduction to Trigonometry","Some Applications of Trigonometry","Circles","Areas Related to Circles",
    "Surface Areas and Volumes","Statistics","Probability"],
  social: ["History: The Rise of Nationalism in Europe","History: Nationalism in India","History: The Making of a Global World",
    "History: The Age of Industrialisation","History: Print Culture and the Modern World",
    "Geography: Resources and Development","Geography: Forest and Wildlife Resources","Geography: Water Resources","Geography: Agriculture",
    "Geography: Minerals and Energy Resources","Geography: Manufacturing Industries","Geography: Lifelines of National Economy",
    "Political Science: Power Sharing","Political Science: Federalism","Political Science: Gender, Religion and Caste",
    "Political Science: Political Parties","Political Science: Outcomes of Democracy",
    "Economics: Development","Economics: Sectors of the Indian Economy","Economics: Money and Credit","Economics: Globalisation and the Indian Economy"]
};

window.CHEATSHEETS = {
// ======================= PHYSICS =======================
"Light – Reflection and Refraction": [
  ["Reflection", [
    "Angle of incidence = angle of reflection; incident ray, reflected ray and normal lie in one plane.",
    "Plane mirror: virtual, erect, same size, as far behind as the object is in front, laterally inverted.",
    "R = 2f (radius of curvature is twice the focal length).",
    "<b>Concave mirror</b>: real & inverted images (object beyond F); virtual, erect, enlarged (object between P and F). Uses: torches, shaving/dentist mirrors, solar furnaces.",
    "<b>Convex mirror</b>: always virtual, erect, diminished. Use: rear-view mirror (wider field of view)."]],
  ["Concave mirror image positions", [
    "At infinity → image at F, highly diminished, real.",
    "Beyond C → between F and C, diminished. At C → at C, same size.",
    "Between C and F → beyond C, enlarged. At F → at infinity.",
    "Between P and F → behind mirror, virtual, erect, enlarged."]],
  ["Refraction", [
    "Light bends towards the normal entering a denser medium, away from it entering a rarer one.",
    "Snell's law: sin i / sin r = constant = n.",
    "Refractive index n = c/v (speed in vacuum ÷ speed in medium). n<sub>21</sub> = n<sub>2</sub>/n<sub>1</sub>.",
    "Glass slab: emergent ray is parallel to incident ray but shifted sideways (lateral displacement).",
    "<b>Convex lens</b> (converging): real or virtual images. <b>Concave lens</b> (diverging): always virtual, erect, diminished."]],
  ["Formulas & sign convention", [
    "Mirror: 1/v + 1/u = 1/f; m = h′/h = −v/u.",
    "Lens: 1/v − 1/u = 1/f; m = h′/h = v/u.",
    "Power P = 1/f (f in metres); unit dioptre (D). Convex +, concave −.",
    "Distances measured from the pole/optical centre; along the incident light = +, against it = −. Heights above axis +.",
    "Concave mirror & concave lens: f negative. Convex mirror & convex lens: f positive."]]
],
"The Human Eye and the Colourful World": [
  ["The eye", [
    "Light enters through the cornea; iris controls pupil size; eye lens forms a real, inverted image on the retina.",
    "Ciliary muscles change lens thickness → <b>power of accommodation</b>.",
    "Near point ≈ 25 cm (least distance of distinct vision); far point = infinity.",
    "Cataract: lens becomes milky/cloudy; treated by surgery."]],
  ["Defects of vision", [
    "<b>Myopia</b> (near-sightedness): can't see far; image forms in front of retina; cause: eyeball too long or lens too curved; correct with a <b>concave</b> lens.",
    "<b>Hypermetropia</b> (far-sightedness): can't see near; image behind retina; correct with a <b>convex</b> lens.",
    "<b>Presbyopia</b>: in old age, ciliary muscles weaken; often needs bifocal lenses."]],
  ["Prism & atmosphere", [
    "Dispersion: prism splits white light into VIBGYOR; violet bends most, red least.",
    "Isaac Newton recombined the spectrum into white light with a second inverted prism.",
    "Rainbow: dispersion + refraction + internal reflection in raindrops; seen with the Sun behind you.",
    "Atmospheric refraction: twinkling of stars, advance sunrise and delayed sunset (~2 min each).",
    "Scattering: blue sky (short wavelengths scattered most), red sunrise/sunset (long path; blue scattered away), Tyndall effect.",
    "Danger signals are red because red scatters least and travels far in fog/smoke."]]
],
"Electricity": [
  ["Basics", [
    "Current I = Q/t; unit ampere (A). 1 C ≈ charge of 6 × 10<sup>18</sup> electrons.",
    "Potential difference V = W/Q; unit volt (V). Measured by a voltmeter in <b>parallel</b>; ammeter in <b>series</b>.",
    "Ohm's law: V = IR (at constant temperature). Unit of resistance: ohm (Ω).",
    "R = ρL/A. Resistance increases with length, decreases with area, depends on material and temperature.",
    "Resistivity ρ (Ω m) depends only on material and temperature. Alloys (nichrome) have high ρ → heating elements."]],
  ["Combinations", [
    "Series: R = R<sub>1</sub> + R<sub>2</sub> + …; same current through each; voltages add.",
    "Parallel: 1/R = 1/R<sub>1</sub> + 1/R<sub>2</sub> + …; same voltage across each; currents add.",
    "Parallel equivalent is smaller than the smallest resistor. Homes use parallel wiring so each appliance gets full voltage and can be switched separately."]],
  ["Heating & power", [
    "Joule's law: H = I<sup>2</sup>Rt.",
    "Power P = VI = I<sup>2</sup>R = V<sup>2</sup>/R; unit watt (W).",
    "Energy (commercial unit) 1 kWh = 3.6 × 10<sup>6</sup> J = 1 'unit'.",
    "Uses of heating: electric iron, heater, bulb filament (tungsten, melting point 3380 °C), fuse (low melting point wire in series)."]]
],
"Magnetic Effects of Electric Current": [
  ["Field lines", [
    "Go from N to S outside a magnet and S to N inside; closed curves; never intersect; closer lines = stronger field.",
    "Hans Christian Oersted discovered that current produces a magnetic field.",
    "Straight wire: concentric circles; direction by the <b>right-hand thumb rule</b>. Field ∝ current, decreases with distance.",
    "Circular loop: field lines nearly straight at the centre. Solenoid: uniform field inside (parallel lines), acts like a bar magnet.",
    "Electromagnet: solenoid with a soft iron core; magnetic only while current flows."]],
  ["Force on a conductor", [
    "A current-carrying conductor in a magnetic field feels a force; maximum when current ⊥ field.",
    "<b>Fleming's left-hand rule</b>: Forefinger = Field, Middle finger = Current, Thumb = Motion (force).",
    "Used in electric motors, loudspeakers, galvanometers."]],
  ["Domestic circuits", [
    "Live wire (red insulation), neutral (black), earth (green). Potential difference between live and neutral in India: 220 V.",
    "Earth wire protects from shocks by giving leaking current a low-resistance path to the ground.",
    "Fuse/MCB protects against overloading and short-circuiting.",
    "Overloading: too many appliances on one socket; short circuit: live and neutral touch."]]
],

// ======================= CHEMISTRY =======================
"Chemical Reactions and Equations": [
  ["Signs of a reaction", ["Change in state, colour, temperature, evolution of gas, formation of precipitate."]],
  ["Balancing", [
    "Balance to obey the <b>law of conservation of mass</b>: same number of each atom on both sides.",
    "Show states: (s), (l), (g), (aq). Example: 3Fe + 4H<sub>2</sub>O → Fe<sub>3</sub>O<sub>4</sub> + 4H<sub>2</sub>."]],
  ["Types of reactions", [
    "<b>Combination</b>: A + B → AB. CaO + H<sub>2</sub>O → Ca(OH)<sub>2</sub> (exothermic, quicklime → slaked lime).",
    "<b>Decomposition</b>: AB → A + B. Thermal: CaCO<sub>3</sub> → CaO + CO<sub>2</sub>; 2FeSO<sub>4</sub> → Fe<sub>2</sub>O<sub>3</sub> + SO<sub>2</sub> + SO<sub>3</sub>; 2Pb(NO<sub>3</sub>)<sub>2</sub> → 2PbO + 4NO<sub>2</sub> + O<sub>2</sub> (brown fumes). Electrolytic: 2H<sub>2</sub>O → 2H<sub>2</sub> + O<sub>2</sub> (H<sub>2</sub> volume = 2 × O<sub>2</sub>). Photolytic: 2AgCl → 2Ag + Cl<sub>2</sub> (black & white photography).",
    "<b>Displacement</b>: more reactive metal displaces less reactive. Fe + CuSO<sub>4</sub> → FeSO<sub>4</sub> + Cu (blue → green).",
    "<b>Double displacement</b>: exchange of ions. Na<sub>2</sub>SO<sub>4</sub> + BaCl<sub>2</sub> → BaSO<sub>4</sub>↓ (white) + 2NaCl. Pb(NO<sub>3</sub>)<sub>2</sub> + 2KI → PbI<sub>2</sub>↓ (yellow) + 2KNO<sub>3</sub>.",
    "Decomposition reactions are usually endothermic; combination and respiration are exothermic."]],
  ["Oxidation & reduction", [
    "Oxidation: gain of oxygen / loss of hydrogen. Reduction: loss of oxygen / gain of hydrogen.",
    "Redox: CuO + H<sub>2</sub> → Cu + H<sub>2</sub>O (CuO reduced, H<sub>2</sub> oxidised).",
    "Oxidising agent gives oxygen / gets reduced; reducing agent gets oxidised.",
    "Corrosion (rusting of iron, black coat on silver, green coat on copper) and rancidity (oxidation of fats; prevented by antioxidants, airtight packing, nitrogen flushing)."]]
],
"Acids, Bases and Salts": [
  ["Indicators", [
    "Litmus: acid turns blue → red; base turns red → blue.",
    "Phenolphthalein: colourless in acid, <b>pink</b> in base. Methyl orange: red in acid, yellow in base.",
    "Turmeric turns reddish-brown in bases. Olfactory indicators: onion, vanilla, clove."]],
  ["Reactions", [
    "Acid + metal → salt + H<sub>2</sub> (burns with a pop).",
    "Acid + metal carbonate/hydrogencarbonate → salt + H<sub>2</sub>O + CO<sub>2</sub> (turns lime water milky; excess CO<sub>2</sub> makes it clear again).",
    "Acid + base → salt + water (<b>neutralisation</b>).",
    "Acid + metal oxide → salt + water (metal oxides are basic). Non-metal oxides are acidic.",
    "Base + some metals (Zn) → salt + H<sub>2</sub>: 2NaOH + Zn → Na<sub>2</sub>ZnO<sub>2</sub> + H<sub>2</sub>.",
    "Acids give H<sup>+</sup> (H<sub>3</sub>O<sup>+</sup>) ions in water; bases give OH<sup>−</sup>. Water-soluble bases are alkalis.",
    "Diluting: always add acid to water, slowly with stirring (highly exothermic)."]],
  ["pH", [
    "0–14 scale. 7 neutral, below 7 acidic, above 7 basic. Lower pH = more H<sup>+</sup> = stronger acid.",
    "Tooth decay below pH 5.5; stomach has HCl (acid indigestion → antacid like Mg(OH)<sub>2</sub>); acid rain below 5.6; plants need specific soil pH.",
    "Bee sting (methanoic acid) → baking soda; nettle sting → dock plant leaf."]],
  ["Important salts", [
    "Common salt NaCl → chlor-alkali process: 2NaCl + 2H<sub>2</sub>O → 2NaOH + Cl<sub>2</sub> + H<sub>2</sub>.",
    "Bleaching powder CaOCl<sub>2</sub> (Cl<sub>2</sub> on dry slaked lime): bleaching, disinfecting water.",
    "Baking soda NaHCO<sub>3</sub>: mild non-corrosive base; antacid, baking powder (with tartaric acid), fire extinguishers.",
    "Washing soda Na<sub>2</sub>CO<sub>3</sub>·10H<sub>2</sub>O: removes permanent hardness, glass/soap industry.",
    "Plaster of Paris CaSO<sub>4</sub>·½H<sub>2</sub>O: from heating gypsum CaSO<sub>4</sub>·2H<sub>2</sub>O at 373 K; used for fractures, toys.",
    "Water of crystallisation: CuSO<sub>4</sub>·5H<sub>2</sub>O is blue; turns white on heating."]]
],
"Metals and Non-metals": [
  ["Properties", [
    "Metals: lustrous, hard (except Na, K), malleable, ductile, good conductors, sonorous, high melting points (except Hg, Ga, Cs).",
    "Mercury is a liquid metal; gallium and caesium melt in the palm. Gold and silver are most malleable/ductile; silver and copper best conductors.",
    "Non-metals: brittle, poor conductors (except graphite). Bromine is a liquid non-metal. Iodine is lustrous. Diamond is the hardest natural substance."]],
  ["Reactions of metals", [
    "Metal + oxygen → metal oxide (basic). Al<sub>2</sub>O<sub>3</sub> and ZnO are <b>amphoteric</b> (react with acids and bases).",
    "Na and K are kept in kerosene (catch fire in air). Mg burns with a dazzling white flame.",
    "Metal + water → metal oxide/hydroxide + H<sub>2</sub> (Na, K violently; Ca less; Mg with hot water; Al, Fe, Zn with steam; Pb, Cu, Ag, Au not at all).",
    "Reactivity series: K > Na > Ca > Mg > Al > Zn > Fe > Pb > [H] > Cu > Hg > Ag > Au.",
    "Aqua regia: 3 parts conc. HCl + 1 part conc. HNO<sub>3</sub>; dissolves gold and platinum."]],
  ["Ionic compounds", [
    "Formed by transfer of electrons (e.g. Na → Na<sup>+</sup>, Cl → Cl<sup>−</sup>).",
    "Solids, hard, high melting and boiling points, soluble in water (not in kerosene), conduct only when molten or dissolved."]],
  ["Metallurgy & corrosion", [
    "Minerals → ores. Remove gangue. Low-reactivity metals (Hg) by heating; middle (Zn, Fe, Pb) by <b>roasting</b> (sulphide ores, excess air) or <b>calcination</b> (carbonate ores, limited air), then reduction with carbon; highly reactive (Na, Mg, Al) by electrolysis.",
    "Thermite reaction: Fe<sub>2</sub>O<sub>3</sub> + 2Al → 2Fe + Al<sub>2</sub>O<sub>3</sub> + heat (joins railway tracks).",
    "Electrolytic refining: impure metal = anode, pure metal = cathode.",
    "Rusting needs air and water. Prevention: painting, oiling, galvanisation (zinc coating), alloying (stainless steel).",
    "Alloys: brass (Cu + Zn), bronze (Cu + Sn), solder (Pb + Sn, low melting point), amalgam (with mercury)."]]
],
"Carbon and its Compounds": [
  ["Bonding", [
    "Carbon (2, 4) has valency 4 and forms <b>covalent bonds</b> by sharing electrons.",
    "Covalent compounds: low melting/boiling points, poor conductors.",
    "Allotropes: diamond (hard, each C bonded to 4), graphite (layers, conducts), fullerenes (C-60).",
    "Why so many compounds: <b>catenation</b> (bonds with other C atoms in chains/rings) and <b>tetravalency</b>."]],
  ["Hydrocarbons", [
    "Alkanes C<sub>n</sub>H<sub>2n+2</sub> (single bonds, saturated). Alkenes C<sub>n</sub>H<sub>2n</sub> (C=C). Alkynes C<sub>n</sub>H<sub>2n−2</sub> (C≡C).",
    "Homologous series: same functional group, successive members differ by CH<sub>2</sub> (14 u); similar chemical properties, gradation in physical properties.",
    "Functional groups: –OH alcohol (-ol), –CHO aldehyde (-al), &gt;C=O ketone (-one), –COOH carboxylic acid (-oic acid), –Cl/–Br halo (chloro-/bromo-)."]],
  ["Reactions", [
    "Combustion: C + O<sub>2</sub> → CO<sub>2</sub> + heat + light. Saturated hydrocarbons burn with a clean blue flame; unsaturated give a sooty yellow flame.",
    "Oxidation: ethanol → ethanoic acid (alkaline KMnO<sub>4</sub> or acidified K<sub>2</sub>Cr<sub>2</sub>O<sub>7</sub>).",
    "Addition: unsaturated + H<sub>2</sub> (Ni/Pd catalyst) → saturated (hydrogenation of oils).",
    "Substitution: CH<sub>4</sub> + Cl<sub>2</sub> → CH<sub>3</sub>Cl + HCl (in sunlight)."]],
  ["Ethanol & ethanoic acid", [
    "Ethanol + Na → sodium ethoxide + H<sub>2</sub>. Ethanol + excess conc. H<sub>2</sub>SO<sub>4</sub> at 443 K → ethene (dehydration).",
    "Ethanoic acid (acetic acid): 5–8% solution is vinegar; pure form freezes in winter → glacial acetic acid.",
    "Esterification: acid + alcohol → ester (sweet smell) + water. Saponification: ester + NaOH → soap.",
    "Soaps: sodium/potassium salts of long-chain carboxylic acids; form micelles to remove oil; form scum in hard water. Detergents work in hard water."]]
],

// ======================= BIOLOGY =======================
"Life Processes": [
  ["Nutrition", [
    "Autotrophic: 6CO<sub>2</sub> + 12H<sub>2</sub>O → C<sub>6</sub>H<sub>12</sub>O<sub>6</sub> + 6O<sub>2</sub> + 6H<sub>2</sub>O (sunlight, chlorophyll). Steps: absorb light, split water, reduce CO<sub>2</sub>.",
    "Stomata: gas exchange; open/close by guard cells taking in/losing water.",
    "Heterotrophic: holozoic (Amoeba — pseudopodia, food vacuole), saprophytic (fungi), parasitic (Cuscuta, ticks, lice, tapeworm).",
    "Human digestion: mouth (salivary amylase: starch → sugar) → oesophagus (peristalsis) → stomach (HCl, pepsin, mucus) → small intestine (bile from liver emulsifies fats; pancreatic juice: trypsin, lipase, amylase; villi absorb) → large intestine (absorbs water)."]],
  ["Respiration", [
    "Glucose → pyruvate (in cytoplasm).",
    "Aerobic (mitochondria): pyruvate → CO<sub>2</sub> + water + lots of energy (ATP).",
    "Anaerobic in yeast: pyruvate → ethanol + CO<sub>2</sub>. In muscles (lack of O<sub>2</sub>): → lactic acid (cramps).",
    "Human: nostrils → pharynx → larynx → trachea (rings of cartilage) → bronchi → bronchioles → alveoli (thin walls, rich blood supply). Haemoglobin carries O<sub>2</sub>."]],
  ["Transportation", [
    "Heart: 4 chambers (2 atria, 2 ventricles). Left side: oxygenated blood; right side: deoxygenated. Valves prevent backflow.",
    "Double circulation in birds and mammals. Fish: 2-chambered heart, single circulation. Amphibians/most reptiles: 3 chambers.",
    "Arteries carry blood away from the heart (thick walls); veins bring it back (valves); capillaries allow exchange.",
    "Platelets help clotting; lymph carries digested fat and drains excess fluid.",
    "Plants: xylem carries water & minerals (transpiration pull, root pressure); phloem carries food (translocation, uses ATP)."]],
  ["Excretion", [
    "Kidneys → ureters → urinary bladder → urethra. Nephron = filtering unit (glomerulus + Bowman's capsule + tubule).",
    "Useful substances (glucose, amino acids, salts, much water) are reabsorbed in the tubule.",
    "Dialysis: artificial kidney for kidney failure.",
    "Plants: remove O<sub>2</sub> and water; store wastes in leaves that fall, as resins and gums in old xylem, or release into soil."]]
],
"Control and Coordination": [
  ["Nervous system", [
    "Neuron: dendrite → cell body → axon → nerve ending. Synapse = gap between neurons (chemical transmission).",
    "Reflex action: quick, automatic; reflex arc goes through the <b>spinal cord</b>.",
    "Forebrain (cerebrum): thinking, senses, voluntary actions; hypothalamus: hunger.",
    "Midbrain: some involuntary actions (pupil). Hindbrain: medulla (BP, salivation, vomiting), pons, <b>cerebellum</b> (posture, balance, precision).",
    "Brain protected by the skull and fluid; spinal cord by the vertebral column."]],
  ["Plants", [
    "Immediate movement: touch-me-not (Mimosa) folds by water movement in cells, not growth.",
    "Tropisms (growth): phototropism (light), geotropism (gravity), hydrotropism (water), chemotropism (pollen tube).",
    "Hormones: <b>auxin</b> (cell elongation, bending towards light), <b>gibberellin</b> (stem growth), <b>cytokinin</b> (cell division), <b>abscisic acid</b> (inhibits growth, wilting)."]],
  ["Human hormones", [
    "Pituitary: growth hormone (dwarfism/gigantism). Thyroid: thyroxine (needs iodine; lack → goitre).",
    "Pancreas: insulin (lowers blood sugar; lack → diabetes). Adrenal: adrenaline (fight or flight).",
    "Testes: testosterone. Ovaries: oestrogen. Hypothalamus releases hormones that control the pituitary.",
    "Feedback mechanisms control timing and amount of hormones."]]
],
"How do Organisms Reproduce?": [
  ["Basics", [
    "DNA copying with small variations → basis of evolution; variation helps survival of species.",
    "Asexual: one parent, offspring nearly identical."]],
  ["Asexual methods", [
    "Fission: binary (Amoeba, Leishmania), multiple (Plasmodium).",
    "Fragmentation: Spirogyra. Regeneration: Planaria, Hydra.",
    "Budding: Hydra, yeast. Spore formation: Rhizopus (bread mould).",
    "Vegetative propagation: roots, stems, leaves (Bryophyllum leaf buds); banana, orange, rose, sugarcane; layering, grafting. Tissue culture."]],
  ["Flowering plants", [
    "Stamen (anther + filament) = male; pistil/carpel (stigma, style, ovary) = female.",
    "Pollination: transfer of pollen to stigma (self or cross; by wind, water, animals).",
    "Fertilisation in the ovule → zygote → embryo; ovule → seed; ovary → fruit.",
    "Germination: seed has plumule (shoot), radicle (root), cotyledons (food)."]],
  ["Human reproduction", [
    "Puberty: changes due to hormones (testosterone, oestrogen).",
    "Male: testes (sperm + testosterone; outside the body in the scrotum for lower temperature) → vas deferens → urethra; seminal vesicles and prostate add fluid.",
    "Female: ovaries release one egg a month → oviduct (fertilisation) → uterus (implantation). Placenta supplies food and O<sub>2</sub>, removes wastes. Gestation ~9 months.",
    "Menstruation when the egg is not fertilised.",
    "Contraception: barrier (condoms — also protect against STDs), hormonal pills, IUDs (copper-T), surgery (vasectomy, tubectomy). Female foeticide is illegal."]]
],
"Heredity": [
  ["Key ideas", [
    "Variation arises during reproduction; more in sexual reproduction.",
    "Gregor Mendel worked with garden pea; traits are controlled by pairs of factors (genes), one from each parent.",
    "Dominant trait shows in F<sub>1</sub>; recessive shows only when both copies are recessive (tt)."]],
  ["Mendel's crosses", [
    "Monohybrid (Tall TT × dwarf tt): F<sub>1</sub> all tall (Tt). F<sub>2</sub> phenotype 3 tall : 1 dwarf; genotype 1 TT : 2 Tt : 1 tt.",
    "Dihybrid (round yellow RRYY × wrinkled green rryy): F<sub>2</sub> 9 : 3 : 3 : 1 → traits are inherited independently.",
    "Genes → proteins/enzymes → traits (e.g. enzyme efficiency → amount of growth hormone → height)."]],
  ["Sex determination", [
    "Humans: women XX, men XY. Egg always carries X; sperm carries X or Y.",
    "Father's sperm decides the sex of the child: X → girl, Y → boy.",
    "In some animals, temperature decides sex (some reptiles); snails can change sex."]]
],
"Our Environment": [
  ["Ecosystem", [
    "Biotic (living) + abiotic (non-living) components.",
    "Producers (green plants) → herbivores (primary consumers) → carnivores (secondary/tertiary consumers). Decomposers (bacteria, fungi) recycle nutrients.",
    "Food chain: each step is a trophic level. Food web: interconnected food chains."]],
  ["Energy flow", [
    "Producers capture about 1% of sunlight falling on leaves.",
    "<b>10% law</b>: only about 10% of energy passes to the next level; so food chains usually have 3–4 levels.",
    "Energy flow is unidirectional.",
    "<b>Biological magnification</b>: non-biodegradable chemicals (pesticides) concentrate at higher levels; top consumers (humans) have the most."]],
  ["Ozone & waste", [
    "Ozone (O<sub>3</sub>) layer absorbs harmful UV rays (which cause skin cancer). Formed when UV splits O<sub>2</sub> and O combines with O<sub>2</sub>.",
    "CFCs (fridges, sprays) deplete ozone; UNEP agreement in 1987 to freeze CFC production.",
    "Biodegradable wastes are broken down by microbes; non-biodegradable (plastics) persist and harm the ecosystem.",
    "Reduce, reuse, recycle; compost kitchen waste; segregate waste."]]
],

// ======================= MATHS =======================
"Real Numbers": [
  ["Key results", [
    "Fundamental Theorem of Arithmetic: every composite number is a product of primes in a unique way (ignoring order).",
    "HCF = product of smallest powers of common prime factors. LCM = product of greatest powers of all prime factors.",
    "For two numbers: HCF × LCM = product of the numbers (not true for three numbers).",
    "HCF is always a factor of LCM."]],
  ["Irrational numbers", [
    "√p is irrational for any prime p (√2, √3, √5…). Proof by contradiction: assume √p = a/b in lowest terms.",
    "Sum/difference of a rational and an irrational is irrational; non-zero rational × irrational is irrational.",
    "A number ending in 0 needs both 2 and 5 as prime factors, so 4<sup>n</sup>, 6<sup>n</sup>… (without a 5) can never end in 0."]]
],
"Polynomials": [
  ["Basics", [
    "Degree 1: linear (at most 1 zero). Degree 2: quadratic (at most 2 zeroes). Degree 3: cubic (at most 3).",
    "Zeroes = x-coordinates where the graph y = p(x) meets the x-axis. A quadratic's graph is a parabola."]],
  ["Relations for ax² + bx + c", [
    "Sum of zeroes α + β = −b/a.",
    "Product αβ = c/a.",
    "Quadratic with given zeroes: k[x<sup>2</sup> − (sum)x + (product)].",
    "Equal zeroes ⇒ b<sup>2</sup> = 4ac. Zeroes are negatives of each other ⇒ b = 0. Reciprocal zeroes ⇒ a = c."]],
  ["Cubic ax³ + bx² + cx + d", [
    "α + β + γ = −b/a; αβ + βγ + γα = c/a; αβγ = −d/a."]]
],
"Pair of Linear Equations in Two Variables": [
  ["Graphs & consistency", [
    "a<sub>1</sub>/a<sub>2</sub> ≠ b<sub>1</sub>/b<sub>2</sub> → intersecting lines → unique solution (consistent).",
    "a<sub>1</sub>/a<sub>2</sub> = b<sub>1</sub>/b<sub>2</sub> = c<sub>1</sub>/c<sub>2</sub> → coincident lines → infinitely many solutions (dependent, consistent).",
    "a<sub>1</sub>/a<sub>2</sub> = b<sub>1</sub>/b<sub>2</sub> ≠ c<sub>1</sub>/c<sub>2</sub> → parallel lines → no solution (inconsistent)."]],
  ["Methods", [
    "Substitution: express one variable in terms of the other, substitute.",
    "Elimination: multiply to make coefficients equal, then add/subtract.",
    "Trick: if coefficients are swapped (ax + by = p, bx + ay = q), add and subtract the equations.",
    "x = a is a vertical line, y = b is a horizontal line; they always intersect at (a, b)."]]
],
"Quadratic Equations": [
  ["Standard form", ["ax<sup>2</sup> + bx + c = 0, a ≠ 0."]],
  ["Solving", [
    "Factorisation: split the middle term (find two numbers with product ac and sum b).",
    "Quadratic formula: x = [−b ± √(b<sup>2</sup> − 4ac)] / 2a."]],
  ["Nature of roots (D = b² − 4ac)", [
    "D > 0: two distinct real roots (rational if D is a perfect square, else irrational).",
    "D = 0: two equal real roots, x = −b/2a.",
    "D < 0: no real roots.",
    "Word problems: ages, speed–time, area; reject answers that don't make sense (negative time, length)."]]
],
"Arithmetic Progressions": [
  ["Formulas", [
    "AP: a, a + d, a + 2d, … (d = common difference = a<sub>2</sub> − a<sub>1</sub>).",
    "n-th term: a<sub>n</sub> = a + (n − 1)d.",
    "n-th term from the end: l − (n − 1)d.",
    "Sum: S<sub>n</sub> = n/2 [2a + (n − 1)d] = n/2 (a + l).",
    "a<sub>n</sub> = S<sub>n</sub> − S<sub>n−1</sub>.",
    "Sum of first n natural numbers = n(n + 1)/2.",
    "Three terms in AP: a − d, a, a + d. If a, b, c are in AP: 2b = a + c.",
    "If a<sub>n</sub> is linear in n (like 7n − 4), the coefficient of n is d."]]
],
"Triangles": [
  ["Similarity", [
    "Similar figures: same shape; corresponding angles equal and sides in the same ratio. All congruent figures are similar.",
    "Criteria: AAA (or AA), SSS, SAS.",
    "In similar triangles, ratio of perimeters, altitudes, medians and angle bisectors = ratio of corresponding sides."]],
  ["Basic Proportionality Theorem (Thales)", [
    "If DE ∥ BC in △ABC, then AD/DB = AE/EC. Converse is also true.",
    "Also AD/AB = AE/AC = DE/BC.",
    "Midpoint theorem: the line joining midpoints of two sides is parallel to the third and half of it."]],
  ["Useful results", [
    "Pythagoras (for right triangles): hypotenuse<sup>2</sup> = sum of squares of other sides.",
    "Diagonals of a trapezium divide each other proportionally.",
    "Rhombus: diagonals bisect at 90°; side = √[(d<sub>1</sub>/2)<sup>2</sup> + (d<sub>2</sub>/2)<sup>2</sup>]."]]
],
"Coordinate Geometry": [
  ["Formulas", [
    "Distance: √[(x<sub>2</sub> − x<sub>1</sub>)<sup>2</sup> + (y<sub>2</sub> − y<sub>1</sub>)<sup>2</sup>]. From origin: √(x<sup>2</sup> + y<sup>2</sup>).",
    "Section formula (m : n internally): ((mx<sub>2</sub> + nx<sub>1</sub>)/(m + n), (my<sub>2</sub> + ny<sub>1</sub>)/(m + n)).",
    "Midpoint: ((x<sub>1</sub> + x<sub>2</sub>)/2, (y<sub>1</sub> + y<sub>2</sub>)/2).",
    "Centroid of a triangle: ((x<sub>1</sub> + x<sub>2</sub> + x<sub>3</sub>)/3, (y<sub>1</sub> + y<sub>2</sub> + y<sub>3</sub>)/3)."]],
  ["Tips", [
    "Distance of (x, y) from the x-axis = |y|; from the y-axis = |x|.",
    "A point on the x-axis is (x, 0); on the y-axis (0, y). To find the ratio in which an axis divides a segment, use k : 1 and set that coordinate to 0.",
    "Parallelogram: diagonals bisect each other ⇒ A + C = B + D (coordinate-wise).",
    "Collinear points: distance AB + BC = AC.",
    "Identify shapes: rhombus (all sides equal), rectangle (opposite sides equal + equal diagonals), square (both)."]]
],
"Introduction to Trigonometry": [
  ["Ratios (right triangle)", [
    "sin = opposite/hypotenuse, cos = adjacent/hypotenuse, tan = opposite/adjacent.",
    "cosec = 1/sin, sec = 1/cos, cot = 1/tan; tan = sin/cos."]],
  ["Standard values", [
    "sin 0°, 30°, 45°, 60°, 90° = 0, 1/2, 1/√2, √3/2, 1.",
    "cos 0°, 30°, 45°, 60°, 90° = 1, √3/2, 1/√2, 1/2, 0.",
    "tan 0°, 30°, 45°, 60°, 90° = 0, 1/√3, 1, √3, not defined."]],
  ["Identities", [
    "sin<sup>2</sup> A + cos<sup>2</sup> A = 1.",
    "1 + tan<sup>2</sup> A = sec<sup>2</sup> A ⇒ (sec A + tan A)(sec A − tan A) = 1.",
    "1 + cot<sup>2</sup> A = cosec<sup>2</sup> A.",
    "Tip: for (a sin θ + b cos θ)/(c sin θ + d cos θ), divide top and bottom by cos θ to use tan θ.",
    "sin θ and cos θ are never greater than 1."]]
],
"Some Applications of Trigonometry": [
  ["Key ideas", [
    "Line of sight: from the eye to the object.",
    "Angle of elevation: object above the horizontal (looking up). Angle of depression: object below (looking down).",
    "Angle of elevation from A to B = angle of depression from B to A (alternate angles).",
    "Mostly use tan θ = height / horizontal distance.",
    "Useful: tan 30° = 1/√3, tan 45° = 1, tan 60° = √3; √3 ≈ 1.732.",
    "Shadow equal to height ⇒ Sun's elevation 45°. Longer shadow ⇒ smaller angle of elevation.",
    "Always draw a neat figure and mark the right angle first."]]
],
"Circles": [
  ["Tangents", [
    "A tangent touches the circle at exactly one point; a secant cuts it at two points.",
    "The tangent is perpendicular to the radius at the point of contact.",
    "Exactly one tangent at a point on the circle; two tangents from an external point; none from an inside point.",
    "Lengths of tangents from an external point are equal.",
    "Tangent length = √(d<sup>2</sup> − r<sup>2</sup>), d = distance of point from the centre."]],
  ["Useful results", [
    "Angle between two tangents + angle at the centre between the radii = 180°.",
    "The line from the external point to the centre bisects the angle between the tangents.",
    "Quadrilateral circumscribing a circle: AB + CD = AD + BC.",
    "Tangents at the ends of a diameter are parallel."]]
],
"Areas Related to Circles": [
  ["Formulas", [
    "Circumference = 2πr; area = πr<sup>2</sup>.",
    "Length of arc (angle θ) = (θ/360°) × 2πr.",
    "Area of sector = (θ/360°) × πr<sup>2</sup> = ½ × arc length × r.",
    "Area of segment = area of sector − area of triangle.",
    "Area of major sector = πr<sup>2</sup> − minor sector.",
    "Perimeter of sector = 2r + arc length.",
    "Distance in one revolution of a wheel = circumference. Minute hand sweeps 6° per minute.",
    "Use π = 22/7 when r is a multiple of 7; otherwise 3.14."]]
],
"Surface Areas and Volumes": [
  ["Formulas", [
    "Cuboid: TSA 2(lb + bh + hl); V = lbh; diagonal √(l<sup>2</sup> + b<sup>2</sup> + h<sup>2</sup>). Cube: TSA 6a<sup>2</sup>; V = a<sup>3</sup>.",
    "Cylinder: CSA 2πrh; TSA 2πr(r + h); V = πr<sup>2</sup>h.",
    "Cone: slant height l = √(r<sup>2</sup> + h<sup>2</sup>); CSA πrl; TSA πr(l + r); V = ⅓πr<sup>2</sup>h.",
    "Sphere: SA 4πr<sup>2</sup>; V = (4/3)πr<sup>3</sup>.",
    "Hemisphere: CSA 2πr<sup>2</sup>; TSA 3πr<sup>2</sup>; V = (2/3)πr<sup>3</sup>."]],
  ["Combinations", [
    "Surface area of a combined solid = sum of the visible curved surfaces only (don't add the joined faces).",
    "Volume of a combined solid = sum of the volumes.",
    "Recasting/melting: volume stays the same.",
    "Cone and cylinder with same r and h: cone volume = ⅓ cylinder volume."]]
],
"Statistics": [
  ["Grouped data", [
    "Mean (direct): x̄ = Σf<sub>i</sub>x<sub>i</sub> / Σf<sub>i</sub> (x<sub>i</sub> = class mark = (upper + lower)/2).",
    "Assumed mean: x̄ = a + Σf<sub>i</sub>d<sub>i</sub>/Σf<sub>i</sub>. Step deviation: x̄ = a + h × Σf<sub>i</sub>u<sub>i</sub>/Σf<sub>i</sub>.",
    "Mode = l + [(f<sub>1</sub> − f<sub>0</sub>)/(2f<sub>1</sub> − f<sub>0</sub> − f<sub>2</sub>)] × h (modal class = highest frequency).",
    "Median = l + [(n/2 − cf)/f] × h (median class: cumulative frequency just greater than n/2).",
    "Empirical relation: 3 Median = Mode + 2 Mean.",
    "Adding a constant to every observation adds it to mean, median and mode."]]
],
"Probability": [
  ["Key rules", [
    "P(E) = favourable outcomes / total outcomes; 0 ≤ P(E) ≤ 1.",
    "P(E) + P(not E) = 1. Sure event = 1; impossible event = 0.",
    "Coin: 2 outcomes. Two coins: 4 (HH, HT, TH, TT). Die: 6. Two dice: 36.",
    "Two dice: sum 7 → 6 ways; sum 8 → 5 ways; doublets → 6 ways; 'at least one 6' → 11 ways.",
    "Deck of 52: 4 suits × 13; 26 red (hearts, diamonds), 26 black (spades, clubs); 12 face cards (J, Q, K), 4 aces.",
    "Primes on a die: 2, 3, 5. MATHEMATICS: 11 letters, 4 vowels, 8 distinct letters.",
    "If cards are removed, reduce the total before calculating."]]
],

// ======================= SOCIAL SCIENCE =======================
"History: The Rise of Nationalism in Europe": [
  ["Key events & dates", [
    "1789 French Revolution: first clear expression of nationalism (la patrie, le citoyen, tricolour, Estates General → National Assembly).",
    "1804 Napoleonic (Civil) Code: equality before law, abolished privileges by birth, right to property.",
    "1815 Congress of Vienna (host: Metternich, Austria): restored monarchies (Bourbons in France), conservatism.",
    "1830s: Mazzini founds Young Italy (1831) and Young Europe. 1832 Treaty of Constantinople: Greece independent.",
    "1834 Zollverein: customs union led by Prussia.",
    "1848: revolution of liberals; Frankfurt Parliament in the Church of St Paul (failed); Sorrieu's prints.",
    "1861 Victor Emmanuel II king of united Italy. 1871 Kaiser William I proclaimed German Emperor at Versailles."]],
  ["People", [
    "Bismarck: architect of German unification ('blood and iron').",
    "Italy: Mazzini (ideas), Cavour (Sardinia-Piedmont diplomacy), Garibaldi (Red Shirts, 1860 south Italy).",
    "Herder: German folk culture (das volk). Romanticism: emotion, folk songs, language (e.g. Polish in Russia)."]],
  ["Ideas & symbols", [
    "Liberalism (liber = free): individual freedom, equality before law, representative government, free markets.",
    "Britain: Act of Union 1707 (England + Scotland); Ireland added 1801; English culture dominated.",
    "Allegories: Marianne (France), Germania (Germany). Balkans became the 'powder keg' of Europe before WW1."]]
],
"History: Nationalism in India": [
  ["Timeline", [
    "1915 Gandhiji returns from South Africa. 1917 Champaran, Kheda; 1918 Ahmedabad mill workers.",
    "1919 Rowlatt Act; 13 April Jallianwala Bagh (General Dyer), Amritsar.",
    "1920 Khilafat (Shaukat Ali, Muhammad Ali) + Non-Cooperation adopted at Nagpur (Dec). Movement begins Jan 1921.",
    "Feb 1922 Chauri Chaura → Non-Cooperation withdrawn.",
    "1928 Simon Commission ('Go back, Simon'). Dec 1929 Lahore Congress (Nehru): Purna Swaraj; 26 Jan 1930 Independence Day.",
    "12 March–6 April 1930 Salt March (Sabarmati → Dandi) → Civil Disobedience. 1931 Gandhi–Irwin Pact; Second Round Table Conference fails.",
    "Sept 1932 Poona Pact (Gandhi–Ambedkar): reserved seats for Depressed Classes."]],
  ["Different groups", [
    "Awadh peasants: Baba Ramchandra; Oudh Kisan Sabha (1920).",
    "Tribals: Alluri Sitaram Raju, Gudem Hills (Andhra), guerrilla war.",
    "Assam plantation workers: Inland Emigration Act 1859 blocked leaving.",
    "Rich peasants and businessmen (FICCI 1927; G.D. Birla, Purshottamdas Thakurdas) supported Civil Disobedience; Dalits (Ambedkar's Depressed Classes Association 1930) and many Muslims kept a distance."]],
  ["Sense of collective belonging", [
    "Bharat Mata: Bankim Chandra's 'Vande Mataram' (Anandamath); painting by Abanindranath Tagore.",
    "Folklore revival (Tagore; Natesa Sastri in Madras).",
    "Swaraj flag (1921): tricolour with a spinning wheel. Reinterpretation of history to restore pride.",
    "Satyagraha: power of truth, non-violence. Hind Swaraj (1909): British rule survived because of Indian cooperation."]]
],
"History: The Making of a Global World": [
  ["Pre-modern world", [
    "Silk routes: trade in silk, spices; spread of Buddhism, Christianity, Islam.",
    "Food travels: noodles → spaghetti; potatoes, maize, tomatoes, chillies came from the Americas.",
    "Irish Potato Famine 1845–49: ~1 million died.",
    "Conquest of the Americas: germs like smallpox killed native people."]],
  ["19th century (1815–1914)", [
    "Flows: trade, labour, capital. Corn Laws abolished in Britain → cheap food imports.",
    "Technology: railways, steamships, refrigerated ships (meat).",
    "Rinderpest (1890s) killed ~90% of cattle in Africa → forced into wage labour.",
    "Indentured labour from Bihar, UP, central India to the Caribbean, Mauritius, Fiji; Hosay in Trinidad, chutney music; abolished 1921.",
    "Indian bankers abroad: Shikaripuri shroffs, Nattukottai Chettiars."]],
  ["Inter-war & after", [
    "WW1 (1914–18): first modern industrial war. Mass production: Henry Ford's assembly line (T-model).",
    "Great Depression from 1929: agricultural prices fell, US loans recalled; in India, peasants' debts rose and gold was exported.",
    "Bretton Woods Conference 1944 → IMF and World Bank ('Bretton Woods twins'); fixed exchange rates.",
    "Developing countries formed G-77 to demand a New International Economic Order (NIEO)."]]
],
"History: The Age of Industrialisation": [
  ["Before factories", [
    "Proto-industrialisation: merchants gave money to rural producers to make goods for international markets.",
    "Staplers (sort wool), fullers (gather cloth), carders."]],
  ["Factories in Britain", [
    "Cotton was the first symbol of the new era; Richard Arkwright created the cotton mill.",
    "James Watt improved Newcomen's steam engine (patented 1781); Matthew Boulton manufactured it.",
    "Spinning Jenny (James Hargreaves, 1764): one worker, many spindles; women workers attacked it.",
    "Hand labour stayed common: seasonal work, cheap labour, demand for handmade goods by the upper classes."]],
  ["India", [
    "East India Company used gomasthas (paid servants) to control weavers; advances tied weavers to the Company.",
    "Manchester imports and high British duties ruined Indian weavers; the fly shuttle helped some survive.",
    "First cotton mill in Bombay 1854; first jute mill in Bengal 1855 (Rishra). Early industrialists: Dwarkanath Tagore, Dinshaw Petit, Jamsetjee Tata, Seth Hukumchand, G.D. Birla.",
    "Jobbers recruited workers from villages. Swadeshi movement and WW1 boosted Indian industry.",
    "Advertisements, labels and calendars created markets for new goods."]]
],
"History: Print Culture and the Modern World": [
  ["East Asia", [
    "China: woodblock printing from AD 594. Japan: Diamond Sutra (AD 868), oldest printed Japanese book.",
    "Kitagawa Utamaro: ukiyo ('pictures of the floating world'), Edo (Tokyo)."]],
  ["Europe", [
    "Marco Polo brought woodblock printing to Italy (1295).",
    "Johann Gutenberg: printing press (1448); first book the Bible (~180 copies).",
    "Martin Luther's Ninety-Five Theses (1517) → Protestant Reformation.",
    "Menocchio, an Italian miller, reinterpreted the Bible and was executed by the Inquisition. Church's Index of Prohibited Books from 1558.",
    "Mercier: 'Tremble, therefore, tyrants of the world! Tremble before the virtual writer!' Print spread Enlightenment ideas and helped cause the French Revolution.",
    "Chapbooks, penny magazines, lending libraries; books for children and women."]],
  ["India", [
    "Printing press came to Goa with Portuguese missionaries (mid-16th century).",
    "James Augustus Hickey: Bengal Gazette (1780).",
    "Raja Rammohun Roy: Sambad Kaumudi (1821). Jyotiba Phule: Gulamgiri (1871). Kashibaba: Chhote aur Bade ka Sawal (1938).",
    "Women: Rashsundari Debi's autobiography Amar Jiban (1876); Pandita Ramabai wrote about upper-caste Hindu women.",
    "Raja Ravi Varma: mass-produced images. Caricatures and cartoons appeared from the 1870s.",
    "Vernacular Press Act 1878: power to censor Indian-language newspapers."]]
],
"Geography: Resources and Development": [
  ["Resources", [
    "Classification: origin (biotic/abiotic), exhaustibility (renewable/non-renewable), ownership (individual, community, national, international), status (potential, developed, stock, reserves).",
    "Stock: can't be used for lack of technology (e.g. hydrogen from water). Reserves: part of stock usable now.",
    "Sustainable development: meet present needs without harming future generations.",
    "Rio Earth Summit 1992 → Agenda 21. Brundtland Report (1987) 'Our Common Future'. Gandhi: 'enough for everybody's need, not for anybody's greed'."]],
  ["Land", [
    "Relief: plains 43%, mountains 30%, plateaus 27%.",
    "Forest cover target: 33% (National Forest Policy 1952).",
    "Degradation: mining (Jharkhand, Chhattisgarh, MP, Odisha), overgrazing (Gujarat, Rajasthan, MP, Maharashtra), over-irrigation (Punjab, Haryana, western UP)."]],
  ["Soils", [
    "Alluvial: most widespread; northern plains; khadar (new) and bangar (old); sugarcane, paddy, wheat.",
    "Black (regur): Deccan trap; holds moisture; cotton.",
    "Red & yellow: crystalline rocks; red due to iron.",
    "Laterite: high temperature and heavy rain, leaching; cashew with manure.",
    "Arid: sandy, saline (Rajasthan). Forest soils: hilly areas.",
    "Erosion: gullies, bad lands (Chambal ravines), sheet erosion. Conservation: contour ploughing, terracing, strip cropping, shelter belts."]]
],
"Geography: Forest and Wildlife Resources": [
  ["Key facts", [
    "Species categories (IUCN): normal, endangered (black buck, crocodile, Indian wild ass, rhino, lion-tailed macaque, sangai), vulnerable (blue sheep, Asiatic elephant, Gangetic dolphin), rare, endemic (Andaman teal, Nicobar pigeon, Andaman wild pig, mithun), extinct (Asiatic cheetah, pink-headed duck).",
    "Causes of loss: agricultural expansion, mining, big dams, shifting cultivation, poaching.",
    "Indian Wildlife (Protection) Act 1972; Project Tiger 1973."]],
  ["Forest types", [
    "Reserved forests: more than half of forest land; most valuable for conservation (MP has the largest area of permanent forests).",
    "Protected forests: protected from further depletion.",
    "Unclassed forests: belong to government, individuals and communities (NE states, parts of Gujarat)."]],
  ["Community conservation", [
    "Chipko movement (Himalayas). Beej Bachao Andolan (Tehri) and Navdanya: traditional seeds.",
    "Sariska: villagers fought mining. Alwar: 1200 hectares declared 'Bhairodev Dakav Sonchuri'.",
    "Bishnoi community (Rajasthan) protects black buck, chinkara, nilgai.",
    "Joint Forest Management: started in Odisha, 1988; villagers get forest produce and a share of timber.",
    "Sacred groves: forests protected for spiritual reasons (Mundas, Santhals)."]]
],
"Geography: Water Resources": [
  ["Scarcity", [
    "About 3/4 of Earth is water, but only a small share is usable fresh water.",
    "Causes: large and growing population, irrigation for agriculture, industry, urbanisation, over-exploitation and pollution."]],
  ["Multipurpose projects", [
    "Nehru: dams are 'temples of modern India'.",
    "Examples: Bhakra Nangal (Sutlej–Beas; power + irrigation), Hirakud (Mahanadi; water conservation + flood control).",
    "Problems: affect natural flow, sedimentation, aquatic life, displacement, floods, salinisation.",
    "Narmada Bachao Andolan: against Sardar Sarovar Dam (Gujarat); Tehri Dam Andolan."]],
  ["Rainwater harvesting", [
    "Guls/kuls (Western Himalayas), rooftop harvesting (Rajasthan), inundation channels (Bengal), khadins and johads (Rajasthan).",
    "Tankas: underground tanks in Bikaner, Phalodi, Barmer; 'palar pani'.",
    "Bamboo drip irrigation: Meghalaya (200 years old).",
    "Tamil Nadu: first state to make rooftop rainwater harvesting compulsory. Gendathur (Karnataka): village rooftop harvesting."]]
],
"Geography: Agriculture": [
  ["Types of farming", [
    "Primitive subsistence: slash and burn — jhumming (NE), Podu (Andhra), Kumari (Western Ghats), Bewar (MP).",
    "Intensive subsistence: high inputs on small plots; densely populated areas.",
    "Commercial: high-yielding seeds, fertilisers (Punjab, Haryana). Plantation: tea, coffee, rubber, sugarcane, banana."]],
  ["Seasons", [
    "Rabi (sown Oct–Dec, harvested Apr–Jun): wheat, barley, peas, gram, mustard.",
    "Kharif (with monsoon): paddy, maize, jowar, bajra, tur, moong, urad, cotton, jute, groundnut, soybean.",
    "Zaid (short summer season): watermelon, muskmelon, cucumber, fodder."]],
  ["Crops", [
    "Rice: above 25°C, above 100 cm rain; India 2nd largest producer after China.",
    "Wheat: 50–75 cm rain; Ganga–Satluj plains and Deccan black soil.",
    "Millets: jowar, bajra, ragi (rich in iron, calcium; Karnataka). Maize: kharif (also rabi in Bihar).",
    "Pulses: India largest producer and consumer; fix nitrogen (legumes).",
    "Sugarcane: 21–27°C, 75–100 cm rain. Oilseeds: groundnut (kharif), mustard (rabi).",
    "Tea: Assam, Darjeeling, Nilgiris. Coffee: Arabica, Baba Budan Hills (Karnataka).",
    "Rubber: Kerala, TN, Karnataka, A&N Islands, Garo hills. Fibres: cotton (black soil), jute ('golden fibre', West Bengal)."]],
  ["Reforms", ["Green Revolution (HYV seeds), White Revolution (Operation Flood), Bhoodan–Gramdan (Vinoba Bhave), Kisan Credit Card, crop insurance, MSP."]]
],
"Geography: Minerals and Energy Resources": [
  ["Metallic minerals", [
    "Iron: magnetite (finest, ~70% iron, magnetic), hematite (most used, 50–60%). Belts: Odisha–Jharkhand, Durg–Bastar–Chandrapur (Bailadila, Chhattisgarh), Ballari–Chitradurga–Chikkamagaluru–Tumakuru (Kudremukh: 100% export unit), Maharashtra–Goa.",
    "Manganese: steel making; Odisha largest producer.",
    "Bauxite (aluminium): Odisha largest; Panchpatmali (Koraput).",
    "Copper: Balaghat (MP), Khetri (Rajasthan), Singhbhum (Jharkhand)."]],
  ["Non-metallic", [
    "Mica: excellent insulator; Koderma–Gaya–Hazaribagh belt (Jharkhand).",
    "Limestone: cement and iron smelting."]],
  ["Energy", [
    "Coal: peat → lignite (Neyveli) → bituminous (most used) → anthracite (best). Gondwana coal (Damodar valley), tertiary coal (NE).",
    "Petroleum: Mumbai High, Gujarat (Ankeleshwar), Assam (Digboi — oldest). Natural gas: Krishna–Godavari basin; HVJ pipeline.",
    "Nuclear: uranium and thorium (monazite sands of Kerala).",
    "Non-conventional: solar (Madhapur near Bhuj), wind (Nagarcoil–Madurai), tidal (Gulf of Khambhat, Kachchh), geothermal (Parvati valley, Puga valley), biogas ('gobar gas').",
    "Rat-hole mining in Jowai and Cherapunjee (Meghalaya)."]]
],
"Geography: Manufacturing Industries": [
  ["Classification", [
    "By raw material: agro-based (cotton, jute, sugar) and mineral-based (iron & steel, cement).",
    "By role: basic/key (iron & steel) vs consumer industries.",
    "By ownership: public (BHEL, SAIL), private (TISCO, Bajaj Auto, Dabur), joint (Oil India Ltd), cooperative (sugar in Maharashtra, coir in Kerala).",
    "By bulk: heavy (iron & steel) vs light (electrical goods)."]],
  ["Key industries", [
    "Cotton textiles: first mill in Mumbai 1854; Maharashtra and Gujarat.",
    "Jute: first mill near Kolkata (Rishra) 1855; Hugli basin; India largest producer of raw jute and jute goods.",
    "Sugar: mills shifting to south (Maharashtra, Karnataka, TN) for higher sucrose and cooperatives.",
    "Iron & steel: 'basic industry'; Chotanagpur plateau; India 2nd largest crude steel producer.",
    "Aluminium smelting: 2nd most important metallurgical industry; Odisha, WB, Kerala, UP, Chhattisgarh.",
    "Cement: first plant in Chennai (1904). IT & electronics: Bengaluru ('electronic capital of India')."]],
  ["Pollution & control", [
    "Air (smoke, SO<sub>2</sub>), water (effluents), thermal (hot water), noise, land pollution.",
    "Control: treat effluents, recycle water, electrostatic precipitators, scrubbers, silencers, rainwater harvesting."]]
],
"Geography: Lifelines of National Economy": [
  ["Roads", [
    "Golden Quadrilateral: Delhi–Kolkata–Chennai–Mumbai (six-lane). North–South corridor: Srinagar–Kanyakumari; East–West: Silchar–Porbandar.",
    "Agencies: NHAI; National Highways by CPWD; Border Roads Organisation (1960); PM Grameen Sadak Yojana for villages."]],
  ["Railways, pipelines, waterways", [
    "Railways: largest public sector undertaking; Konkan Railway along the west coast.",
    "Pipelines: Upper Assam–Kanpur; Salaya (Gujarat)–Jalandhar; HVJ gas pipeline.",
    "NW-1: Ganga, Allahabad–Haldia (1620 km). NW-2: Brahmaputra, Sadiya–Dhubri. NW-3: West Coast Canal, Kerala."]],
  ["Ports & air", [
    "Kandla (Deendayal): first port after independence, tidal port. Mumbai: biggest natural harbour. JNPT near Mumbai.",
    "Marmagao (Goa): iron ore exports. New Mangaluru: Kudremukh ore. Kochchi: natural harbour.",
    "Chennai: one of the oldest artificial ports. Visakhapatnam: deepest, landlocked, well-protected. Paradip (Odisha), Kolkata (inland riverine), Haldia.",
    "Air transport nationalised in 1953; Pawan Hans Helicopters in hilly areas.",
    "Trade: exchange of goods; balance of trade = exports − imports. Tourism earns foreign exchange."]]
],
"Political Science: Power Sharing": [
  ["Belgium vs Sri Lanka", [
    "Belgium: 59% Dutch (Flemish), 40% French (Wallonia), 1% German. Brussels: 80% French, 20% Dutch.",
    "Belgian model: equal Dutch and French ministers in central government, powers to state governments, equal representation in Brussels, community government for each language group.",
    "Sri Lanka: 74% Sinhala, 18% Tamil (13% Sri Lankan, 5% Indian Tamils).",
    "1956 Act: Sinhala the only official language; preferences for Sinhala → majoritarianism → Tamil alienation → civil war."]],
  ["Why share power", [
    "Prudential reason: reduces conflict between social groups; ensures stability.",
    "Moral reason: very spirit of democracy; people have a right to be consulted."]],
  ["Forms", [
    "Horizontal: among legislature, executive, judiciary (checks and balances).",
    "Vertical: central, state, local governments (federal).",
    "Among social groups: community government (Belgium), reserved constituencies (India).",
    "Among political parties, pressure groups and movements: coalitions, competition."]]
],
"Political Science: Federalism": [
  ["Key features", [
    "Two or more levels of government; each has its own jurisdiction guaranteed by the Constitution.",
    "Fundamental changes need consent of both levels; courts settle disputes; sources of revenue specified.",
    "Coming together (USA, Switzerland, Australia) vs holding together (India, Spain, Belgium)."]],
  ["India", [
    "Union List: defence, foreign affairs, banking, communications, currency.",
    "State List: police, trade, commerce, agriculture, irrigation.",
    "Concurrent List: education, forest, trade unions, marriage, adoption, succession (Union law prevails if conflict).",
    "Residuary subjects (e.g. computer software): Union.",
    "Some states have special status (social and historical circumstances); Union Territories run by the Union (Delhi, Chandigarh, Lakshadweep).",
    "Linguistic states; Hindi + 21 other Scheduled Languages (22 in Eighth Schedule); no national language.",
    "Centre–state relations improved after 1990 with coalition governments."]],
  ["Local government (1992 amendment)", [
    "Regular elections compulsory; seats reserved for SC, ST, OBC; at least one-third of seats for women.",
    "State Election Commission conducts elections; states share powers and revenue.",
    "Rural: Gram Panchayat (Sarpanch) → Panchayat Samiti → Zila Parishad. Urban: municipalities, municipal corporations (Mayor).",
    "Gram Sabha: all voters of the village; approves budget, reviews work."]]
],
"Political Science: Gender, Religion and Caste": [
  ["Gender", [
    "Sexual division of labour: housework seen as women's work.",
    "Feminist movements demand equality in personal and family life and in politics.",
    "Issues: lower literacy, lower pay (despite Equal Remuneration Act 1976), low child sex ratio, domestic violence.",
    "Representation: 33% seats in panchayats and municipalities reserved for women; Women's Reservation Act 2023 provides one-third seats in Lok Sabha and assemblies (after delimitation)."]],
  ["Religion", [
    "Communalism: religion as the main basis of the nation; one religion superior; majoritarian dominance or separate state for minority.",
    "Forms: everyday beliefs, political dominance, political mobilisation using religious symbols, communal violence.",
    "India is secular: no official religion; freedom of religion; no discrimination; state can intervene (e.g. ban untouchability)."]],
  ["Caste", [
    "Reformers: Jyotiba Phule, Gandhiji, B.R. Ambedkar, Periyar Ramaswami Naicker.",
    "Caste in politics: parties choose candidates by caste composition, appeal to caste sentiment, universal adult franchise gave voice to backward castes.",
    "But no constituency has a clear majority of one caste; exclusive focus on caste diverts from other issues and can create tensions.",
    "Politics in caste: castes form coalitions and new groupings (backward, forward)."]]
],
"Political Science: Political Parties": [
  ["Basics", [
    "Party: group of people who come together to contest elections and hold power. Three parts: leaders, active members, followers.",
    "Functions: contest elections, put forward policies, make laws, form and run governments, play opposition, shape public opinion, provide access to welfare schemes.",
    "Party systems: one-party (China), two-party (USA, UK), multi-party (India). Coalition: alliance of parties."]],
  ["Recognition", [
    "Election Commission registers parties and gives symbols.",
    "State party: at least 6% votes in a state assembly election and at least 2 seats.",
    "National party: at least 6% votes in Lok Sabha or assembly elections in four states and at least 4 Lok Sabha seats."]],
  ["Challenges & reforms", [
    "Challenges: lack of internal democracy, dynastic succession, growing role of money and muscle power, lack of meaningful choice.",
    "Reforms: anti-defection law (lose seat if you change party), affidavits on property and criminal cases (Supreme Court order), parties must hold organisational elections and file income tax returns.",
    "Suggestions: regulate internal affairs, one-third tickets to women, state funding of elections."]]
],
"Political Science: Outcomes of Democracy": [
  ["What democracy delivers", [
    "Accountable, responsive and legitimate government; transparency (right to information).",
    "Decisions may be slower, but are more acceptable and effective.",
    "Economic growth: from 1950–2000, dictatorships grew slightly faster; democracy does not guarantee growth.",
    "Inequality and poverty remain a challenge in many democracies.",
    "Accommodates social diversity: majority works with minorities; majority is not always one religious or ethnic group.",
    "Dignity and freedom of citizens: women's and Dalits' struggles gained legitimacy.",
    "Democracy's strength: people can complain about it — citizens keep examining and improving it."]]
],
"Economics: Development": [
  ["Key ideas", [
    "Different people have different, even conflicting, development goals (e.g. a dam vs displaced tribal people).",
    "National development: national income; per capita (average) income = total income ÷ population. World Bank classifies countries by it.",
    "Average income hides inequality and doesn't show health, education or safety."]],
  ["Other indicators", [
    "Infant Mortality Rate (deaths under 1 year per 1000 live births), literacy rate, net attendance ratio, life expectancy, BMI.",
    "Kerala: low IMR thanks to basic health and education facilities; Public Distribution System matters.",
    "Human Development Index (UNDP): per capita income + education + health (life expectancy).",
    "Public facilities (schools, hospitals, security) can't be bought with money individually."]],
  ["Sustainability", [
    "Resources must be used so future generations also benefit.",
    "Groundwater is overused in many areas; crude oil reserves will run out.",
    "Sustainable development: use resources without harming the environment."]]
],
"Economics: Sectors of the Indian Economy": [
  ["Sectors", [
    "Primary: agriculture, dairy, fishing, forestry, mining (natural resources).",
    "Secondary: manufacturing (industrial). Tertiary: services — transport, storage, banking, trade, IT, teachers, doctors.",
    "GDP: value of all final goods and services produced within a country in a year (only final goods, to avoid double counting); measured by a central government ministry.",
    "Tertiary sector became the largest producer (2013-14), but primary is still the largest employer."]],
  ["Employment", [
    "Disguised unemployment/underemployment: more people working than needed (common in agriculture).",
    "MGNREGA 2005: right to 100 days of work a year for rural households; unemployment allowance if no work.",
    "Organised sector: registered, regular jobs, paid leave, PF, fixed hours. Unorganised: small, scattered, low and irregular pay, no security.",
    "Public sector: government owns (railways, post office). Private sector: individuals/companies own (TISCO, Reliance); aim is profit."]]
],
"Economics: Money and Credit": [
  ["Money", [
    "Barter needs double coincidence of wants; money is a medium of exchange.",
    "RBI issues currency notes on behalf of the government; rupee is legal tender.",
    "Deposits in banks are demand deposits (withdraw on demand); cheques let you pay without cash.",
    "Banks keep about 15% of deposits as cash; lend the rest; interest on loans > interest on deposits (their income)."]],
  ["Credit", [
    "Terms of credit: interest rate, collateral, documentation, mode of repayment.",
    "Collateral: asset (land, building, vehicle, livestock) used as guarantee.",
    "Credit helps (Salim) or leads to a debt trap (Swapna, when crop fails).",
    "Formal sources: banks, cooperatives (supervised by RBI; lower interest). Informal: moneylenders, traders, relatives (high interest, no supervision).",
    "Poor households depend more on informal sources; formal credit should expand."]],
  ["Self Help Groups", [
    "15–20 members, mostly women; pool savings; lend to members; get bank loans without collateral after 1–2 years.",
    "Grameen Bank (Bangladesh), founded by Muhammad Yunus (Nobel Peace Prize 2006)."]]
],
"Economics: Globalisation and the Indian Economy": [
  ["MNCs", [
    "MNC: owns or controls production in more than one country; goes where labour is cheap and markets are near.",
    "Ways of spreading: joint production with local firms, buying local companies (Cargill bought Parakh Foods), placing large orders with small producers.",
    "Foreign investment = investment by MNCs. Ford Motors came to India in 1995 (with Mahindra, near Chennai)."]],
  ["Globalisation", [
    "Rapid integration of countries through trade, investment, technology and movement of people.",
    "Factors: technology (transport, IT), liberalisation of trade and investment (India from 1991), WTO rules.",
    "Trade barrier: e.g. tariff (tax on imports). Liberalisation = removing barriers.",
    "WTO: aims to liberalise trade; developed countries have kept unfair barriers (e.g. farm subsidies).",
    "SEZs: special zones with world-class facilities and tax benefits to attract investors."]],
  ["Impact", [
    "Benefits: more choice for consumers, new jobs, Indian companies became MNCs (Tata Motors, Infosys).",
    "Problems: small producers face tough competition; flexible labour laws → insecure jobs.",
    "Fair globalisation: benefits for all, protecting workers and small producers."]]
]
};
