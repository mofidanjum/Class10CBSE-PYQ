# CLAUDE.md – project notes for Claude

## What this is
Personal MCQ practice app for a CBSE Class 10 student (Physics, Chemistry, Biology, Maths, Social Science).
Audience: a 15-year-old on an Android phone. Keep the UI simple, large tap targets, plain language.

## Layout
- `web/index.html` – the whole app (no framework, no build step). It is an HTML *fragment*:
  no doctype/head/body, because the same file is also published as a claude.ai Artifact.
  `scripts/build_web.sh` wraps it into a full page for Android.
- `web/questions.js`, `web/cbse_papers.js`, `web/biology.js`, `web/social.js` – question bank. Each file appends to `window.QUESTION_BANK`.
- `web/cheatsheets.js` – `window.CHAPTERS` (chapter order per subject) and `window.CHEATSHEETS` (revision notes per chapter). Every chapter used by a question must be listed in `CHAPTERS`.
- `android/` – WebView wrapper, loads `file:///android_asset/www/index.html`.

## Question rules
- Every question needs: unique `id`, `s`, `ch` (chapter name exactly as in the current CBSE syllabus), `src`, 4 options, `a`, `e`.
- `src` is `"Practice"` for questions we wrote, or e.g. `"CBSE Sample Paper 2024-25"` for official ones.
- Official-paper questions: keep numbers, choices and answers identical to CBSE's marking scheme; wording may be adapted.
- Skip questions that need a figure until we support images.
- After editing, run the validation check (unique ids, 4 distinct options, `a` in 0–3).

## Releasing
Push to `main` → GitHub Actions builds `CBSE10-Quiz.apk` and attaches it to the `latest` release.
Never replace `android/keystore/cbse10quiz.jks`, or installed apps can't be updated.
